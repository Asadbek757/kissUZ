const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN || '';
const ADMIN_ID = String(process.env.ADMIN_TELEGRAM_ID || '');

const app = express();
app.use(express.json());
app.use(express.static('public'));
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true, credentials: true } });

const users = new Map(); // telegramId -> user
const rooms = new Map(); // roomId -> room

function now(){ return Date.now(); }
function roomState(room){
  return {
    id: room.id,
    hostId: room.hostId,
    bottleAngle: room.bottleAngle,
    spinning: room.spinning,
    players: [...room.players.values()].map(p => ({
      id:p.id, name:p.name, username:p.username, photo:p.photo,
      vip:p.vip, hearts:p.hearts, pendingKickUntil:p.pendingKickUntil||0,
      saveCooldownUntil:p.saveCooldownUntil||0
    }))
  };
}
function makeRoomId(){
  return Math.random().toString(36).slice(2,7).toUpperCase();
}
function getOrCreateRoom(){
  let id=makeRoomId();
  while(rooms.has(id)) id=makeRoomId();
  const room={id,hostId:null,bottleAngle:0,spinning:false,players:new Map()};
  rooms.set(id,room); return room;
}
function getUser(id){
  return users.get(String(id));
}
function parseInitData(initData){
  if(!BOT_TOKEN || !initData) return null;
  const params = new URLSearchParams(initData);
  const hash=params.get('hash');
  if(!hash) return null;
  params.delete('hash');
  const dataCheck=[...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
  const secret=crypto.createHmac('sha256','WebAppData').update(BOT_TOKEN).digest();
  const calc=crypto.createHmac('sha256',secret).update(dataCheck).digest('hex');
  if(!crypto.timingSafeEqual(Buffer.from(calc),Buffer.from(hash))) return null;
  const authDate=Number(params.get('auth_date')||0);
  if(!authDate || now()/1000-authDate>86400) return null;
  try { return JSON.parse(params.get('user')); } catch { return null; }
}

app.get('/api/health',(req,res)=>res.json({ok:true, rooms:rooms.size}));

app.post('/api/auth', (req,res)=>{
  const {initData, devUser} = req.body || {};
  let tg = parseInitData(initData);
  if(!tg && process.env.ALLOW_DEV_USERS==='true' && devUser){
    tg={id:String(devUser.id||Date.now()),first_name:devUser.name||'Guest',username:devUser.username||'',photo_url:''};
  }
  if(!tg) return res.status(401).json({error:'Telegram authentication failed'});
  const id=String(tg.id);
  let u=users.get(id);
  if(!u){
    u={id,name:tg.first_name||tg.username||'Player',username:tg.username||'',photo:tg.photo_url||'',vip:false,hearts:100};
    users.set(id,u);
  } else {
    u.name=tg.first_name||u.name; u.username=tg.username||u.username; u.photo=tg.photo_url||u.photo;
  }
  if(ADMIN_ID && id===ADMIN_ID) u.vip=true;
  res.json({user:u, isAdmin: ADMIN_ID && id===ADMIN_ID});
});

app.post('/api/admin/hearts',(req,res)=>{
  const adminId=String(req.body.adminId||'');
  const targetId=String(req.body.targetId||'');
  const amount=Number(req.body.amount);
  if(!ADMIN_ID || adminId!==ADMIN_ID) return res.status(403).json({error:'Admin only'});
  if(!Number.isFinite(amount)) return res.status(400).json({error:'Invalid amount'});
  const u=users.get(targetId);
  if(!u) return res.status(404).json({error:'User not found'});
  u.hearts=Math.max(0,u.hearts+amount);
  io.emit('user:update',u);
  res.json({ok:true,user:u});
});

// Placeholder for Telegram Stars invoice creation. BOT_TOKEN must be configured.
app.post('/api/stars/invoice', async (req,res)=>{
  const {userId, hearts} = req.body || {};
  const packs={100:1,500:5,1000:10}; // Stars; adjust prices before production
  const h=Number(hearts);
  if(!packs[h]) return res.status(400).json({error:'Unknown pack'});
  if(!BOT_TOKEN) return res.status(500).json({error:'BOT_TOKEN not configured'});
  try{
    const r=await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/createInvoiceLink`,{
      method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify({
        title:`KissUZ ❤️ ${h}`,
        description:`KissUZ hearts pack: ${h} ❤️`,
        payload:`hearts:${userId}:${h}`,
        currency:'XTR',
        prices:[{label:`${h} ❤️`,amount:packs[h]}]
      })
    });
    const data=await r.json();
    if(!data.ok) return res.status(502).json({error:data.description||'Telegram error'});
    res.json({ok:true,url:data.result});
  }catch(e){res.status(500).json({error:e.message});}
});

// Telegram webhook: successful Stars payments credit hearts.
app.post('/telegram/webhook',(req,res)=>{
  const update=req.body||{};
  const sp=update.message?.successful_payment;
  if(sp){
    const payload=String(sp.invoice_payload||'');
    const [type,userId,amount]=payload.split(':');
    if(type==='hearts'){
      const u=users.get(String(userId));
      if(u){ u.hearts += Number(amount)||0; io.emit('user:update',u); }
    }
  }
  res.sendStatus(200);
});

io.on('connection',(socket)=>{
  socket.on('auth', ({initData,devUser}={})=>{
    const tg=parseInitData(initData) || (process.env.ALLOW_DEV_USERS==='true' && devUser ? {id:String(devUser.id),first_name:devUser.name,username:devUser.username||'',photo_url:''}:null);
    if(!tg) return socket.emit('error:msg','Telegram authentication failed');
    const id=String(tg.id);
    let u=users.get(id);
    if(!u){u={id,name:tg.first_name||'Player',username:tg.username||'',photo:tg.photo_url||'',vip:false,hearts:100};users.set(id,u);}
    if(ADMIN_ID && id===ADMIN_ID) u.vip=true;
    socket.data.userId=id;
    socket.emit('auth:ok',{user:u,isAdmin:ADMIN_ID===id});
  });

  socket.on('createRoom',()=>{
    const u=getUser(socket.data.userId); if(!u) return;
    const room=getOrCreateRoom(); room.hostId=u.id; room.players.set(u.id,{...u,pendingKickUntil:0});
    socket.join(room.id); socket.emit('room:joined',roomState(room)); io.to(room.id).emit('room:update',roomState(room));
  });

  socket.on('joinRoom',(id)=>{
    const u=getUser(socket.data.userId); const room=rooms.get(String(id||'').toUpperCase());
    if(!u||!room) return socket.emit('error:msg','Room not found');
    if(room.players.size>=8) return socket.emit('error:msg','Room is full');
    const existing=room.players.get(u.id);
    if(existing?.pendingKickUntil && existing.pendingKickUntil>now()) return socket.emit('error:msg','You are pending kick');
    room.players.set(u.id,{...u,pendingKickUntil:0}); socket.join(room.id);
    io.to(room.id).emit('room:update',roomState(room));
  });

  socket.on('spin',()=>{
    const u=getUser(socket.data.userId); if(!u) return;
    const room=[...rooms.values()].find(r=>r.players.has(u.id)); if(!room||room.spinning) return;
    if(room.players.size<2) return socket.emit('error:msg','At least 2 players are needed');
    room.spinning=true;
    const angle=720+Math.floor(Math.random()*3600);
    room.bottleAngle=(room.bottleAngle+angle)%360;
    io.to(room.id).emit('spin:start',{angle});
    setTimeout(()=>{room.spinning=false;io.to(room.id).emit('spin:end',{angle:room.bottleAngle});},3200);
  });

  socket.on('action',(action)=>{
    const u=getUser(socket.data.userId); if(!u) return;
    const room=[...rooms.values()].find(r=>r.players.has(u.id)); if(!room) return;
    io.to(room.id).emit('action:result',{userId:u.id,action:String(action)});
  });

  socket.on('kick',(targetId)=>{
    const u=getUser(socket.data.userId); if(!u?.vip) return socket.emit('error:msg','VIP only');
    const room=[...rooms.values()].find(r=>r.players.has(u.id)); if(!room) return;
    const t=room.players.get(String(targetId)); if(!t||t.id===u.id) return;
    const current=t.pendingKickUntil||0;
    if(current>now()) return;
    if((u.kickCooldownUntil||0)>now()){
      if(u.hearts<15) return socket.emit('error:msg','KICK cooldown: need 15 ❤️');
      u.hearts-=15;
    }
    u.kickCooldownUntil=now()+30*60*1000;
    t.pendingKickUntil=now()+30*1000;
    io.to(room.id).emit('room:update',roomState(room));
    setTimeout(()=>{
      const latest=room.players.get(t.id);
      if(latest && (latest.pendingKickUntil||0)<=now()){
        room.players.delete(t.id);
        io.to(room.id).emit('kicked',{userId:t.id});
        io.to(room.id).emit('room:update',roomState(room));
      }
    },30100);
  });

  socket.on('save',(targetId)=>{
    const u=getUser(socket.data.userId); if(!u) return;
    const room=[...rooms.values()].find(r=>r.players.has(u.id)); if(!room) return;
    const target=String(targetId||u.id);
    if(!u.vip && target!==u.id) return socket.emit('error:msg','Normal user can only save themselves');
    if((u.saveCooldownUntil||0)>now()){
      if(!u.vip) return socket.emit('error:msg','SAVE cooldown: 2 hours');
      if(u.hearts<15) return socket.emit('error:msg','SAVE cooldown: need 15 ❤️');
      u.hearts-=15;
    }
    const t=room.players.get(target); if(!t) return;
    t.pendingKickUntil=0; u.saveCooldownUntil=now()+(u.vip?30:120)*60*1000;
    io.to(room.id).emit('saved',{userId:target,saverId:u.id});
    io.to(room.id).emit('room:update',roomState(room));
  });
});

server.listen(PORT,()=>console.log(`KissUZ server listening on ${PORT}`));

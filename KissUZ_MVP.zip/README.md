# KissUZ MVP
Telegram Mini App multiplayer starter.

## Run
1. `npm install`
2. Copy `.env.example` to `.env` and set `BOT_TOKEN` and `ADMIN_TELEGRAM_ID`.
3. `npm start`
4. Open `http://localhost:3000`.

For production, deploy the whole project (not only `public/`) to a Node.js host. Netlify static hosting alone cannot run this Socket.IO backend.

## Important
- Do not expose BOT_TOKEN in the browser or GitHub.
- Telegram Stars use currency `XTR`; price values in `server.js` are example values and must be changed before launch.
- Payment fulfillment should also be persisted in a real database before production.
